
/**
 * The main class for task 2.
 */
public class Task2 {
   /** The main method.
    *
    * @param args ignored
    */
   public static void main(String[] args) {
      System.out.println("Hello Task2");
   }
}
