/**
 * This is a javadoc.
 */
public class FailingCheckstyleCode
{

   /**
    *
    * @param args
    */
   public static void main(String[] args) 
   {
      for(int I=0;I<10;++I) 
      {
         System.out.println("I is:"+I);
      }
   }

}
