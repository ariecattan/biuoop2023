# Introduction to Object Oriented Programming
# Summer 2022

## Bar Ilan University

### Instructor: Dr. Hemi Leibowitz

### TAs: Hodaya Adler



## About
This course intends to teach the basics of object-oriented programming, through programming in the Java programming language.

## Optional Reading:

[The Java Trail / Tutorials](http://docs.oracle.com/javase/tutorial/reallybigindex.html_)

[Java Language Specification](https://github.com/ariecattan/biuoop2022/blob/main/materials/jls3.pdf)
